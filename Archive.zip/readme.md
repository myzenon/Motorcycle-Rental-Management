An application to management motorcycle rental store
