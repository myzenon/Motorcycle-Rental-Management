angular.module('motorcycleApp')
  .config(function ($routeProvider) {
   $routeProvider
     .when('/', {
       templateUrl : 'templates/overview.html',
       controller : 'OverviewCtrl'
     })
     .when('/management', {
       templateUrl : 'templates/management.html',
       controller : 'ManagementCtrl'
     })
     .otherwise({ redirectTo: '/' })
   ;
  })
;
