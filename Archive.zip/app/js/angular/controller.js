angular.module('motorcycleApp')
  .controller('BarCtrl', function ($rootScope) {

  })
  .controller('OverviewCtrl', function ($rootScope) {
    $rootScope.menu = 'overview';
  })
  .controller('ManagementCtrl', function ($rootScope) {
    $rootScope.menu = 'management';
  })
;
