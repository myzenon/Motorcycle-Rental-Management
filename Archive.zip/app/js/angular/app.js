angular.module('motorcycleApp', ['ngRoute']);
