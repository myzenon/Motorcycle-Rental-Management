window.jQuery = require('./components/jquery/dist/jquery.min.js');
window.$ = jQuery;
window.Hammer = require('./components/Materialize/js/hammer.min.js');

const ipcRenderer = require('electron').ipcRenderer;
